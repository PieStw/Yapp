package stalteri.piero.yapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
